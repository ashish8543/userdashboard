	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
			<li class="ts-label">Main</li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
			<li><a href="feedback.php"><i class="fa fa-envelope"></i> &nbsp;Feedback</a>
			</li>
			<li><a href="notification.php"><i class="fa fa-bell"></i> &nbsp;Notification<sup style="color:red">*</sup></a>
			</li>
			<li><a href="messages.php"><i class="fa fa-envelope"></i> &nbsp;Messages</a>
			</li>
			</ul>
			<p class="text-center" style="color:#ffffff; margin-top: 100px;">Developed by Ashish tripathi</p>
		</nav>

		